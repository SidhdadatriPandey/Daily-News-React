// 'use client'

// import { createContext, useState } from "react"

// interface initialType{
//     query:string,
//     setQuery:React.Dispatch<React.SetStateAction<string>>
// }

// const initialValue={
//     query:"India",
//     setQuery:()=>{}
// }

// const userContext=createContext()
// const AppContext = () => {
//     const[query,setQuery]=useState<string>("India");
//     function fetchData(){
        
//     }
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default AppContext
