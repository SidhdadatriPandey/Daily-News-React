function Title(){
    return(
        <div>
            <h1><i>Daily-news</i></h1>
        </div>
    )
}

export default Title;